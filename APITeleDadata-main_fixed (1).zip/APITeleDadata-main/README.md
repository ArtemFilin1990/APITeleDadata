# Telegram-бот: Проверка компаний по ИНН/ОГРН

Бот для Telegram на Python с двумя режимами проверки контрагентов по ИНН/ОГРН через сервис DaData.

Поддерживаются два рантайма Telegram:
- `aiogram 3.x` (основной, `bot.py`)
- `pyTelegramBotAPI` / TeleBot (альтернативный, `bot_telebot.py`)

## Возможности

| Режим | Описание | Что нужно |
|-------|----------|-----------|
| **DaData напрямую** | Прямой HTTP-запрос к API DaData `findById/party`. Возвращает структурированную карточку с реквизитами, адресом, руководством, ОКВЭД, финансами, контактами, филиалами | `DADATA_API_KEY` |
| **DaData через AI (MCP)** | Нейросеть (GPT-4.1-mini) анализирует компанию через MCP-сервер DaData и выдаёт человекочитаемый отчёт | `DADATA_API_KEY` + `DADATA_SECRET_KEY` + `OPENAI_API_KEY` |

**Интерфейс:**
- `/start` — приветствие + инлайн-меню выбора режима
- Валидация идентификатора: 10/12 цифр = ИНН, 13/15 цифр = ОГРН
- Пакетная обработка: несколько ИНН/ОГРН через пробел, запятую или с новой строки
- Карточка в 1 экран + кнопки: «Подробнее», «Экспорт», «В CRM»
- In-memory TTL-кэш запросов к DaData (30 минут) для снижения расхода лимитов

## Структура проекта

```
inn_checker_bot/
├── bot.py              # Точка входа, запуск polling
├── config.py           # Загрузка .env, константы
├── handlers.py         # Обработчики команд и FSM
├── keyboards.py        # Инлайн-клавиатуры
├── validators.py       # Валидация и парсинг ИНН/ОГРН
├── dadata_direct.py    # Прямой запрос к DaData API
├── dadata_mcp.py       # Запрос через OpenAI + MCP DaData
├── requirements.txt    # Зависимости
├── .env.example        # Шаблон переменных окружения
└── README.md
```

## Получение ключей

### 1. Telegram Bot Token

1. Откройте [@BotFather](https://t.me/BotFather) в Telegram
2. Отправьте `/newbot`, задайте имя и username
3. Скопируйте токен вида `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`

### 2. DaData API Key и Secret Key

1. Зарегистрируйтесь на [dadata.ru](https://dadata.ru)
2. Перейдите в [профиль](https://dadata.ru/profile/#info)
3. Скопируйте **API-ключ** и **Секретный ключ**

> Секретный ключ нужен только для MCP-режима. Для прямого режима достаточно API-ключа.

### 3. OpenAI API Key (для MCP-режима)

1. Зарегистрируйтесь на [platform.openai.com](https://platform.openai.com)
2. Создайте ключ в разделе [API Keys](https://platform.openai.com/api-keys)
3. Убедитесь, что на балансе есть средства (MCP-режим использует модель `gpt-4.1-mini`)

> OpenAI API Key нужен только для режима «DaData через AI (MCP)». Прямой режим работает без него.

## Установка и запуск

### Переменные окружения

> Важно: храните секреты только в локальном `.env` и не коммитьте его в репозиторий.

```env
# Поддерживаются оба нейминга:
TELEGRAM_BOT_TOKEN=...   # или BOT_TOKEN
DADATA_API_KEY=...       # или DADATA_TOKEN
DADATA_SECRET_KEY=...    # или DADATA_SECRET (опционально для direct, обязательно для MCP)
OPENAI_API_KEY=...       # требуется только для MCP

MODE=polling
WEBHOOK_URL=https://<domain>/tg/webhook
PORT=8080
```


### Требования

- Python 3.10+
- pip

### Шаги

```bash
# 1. Клонировать/скопировать проект
cd inn_checker_bot

# 2. Установить зависимости
pip install -r requirements.txt

# 3. Создать .env из шаблона
cp .env.example .env

# 4. Заполнить .env своими ключами
nano .env

# 5. Запустить бота
python bot.py
```

### Быстрый запуск через Makefile

```bash
make install
make run-prod
```

Альтернативный запуск через TeleBot:

```bash
make run-telebot
```

### Docker (опционально)

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["python", "bot.py"]
```

```bash
docker build -t inn-checker-bot .
docker run -d --env-file .env --name inn-bot inn-checker-bot
```

## Использование

1. Откройте бота в Telegram
2. Отправьте `/start`
3. Выберите режим:
   - **DaData напрямую** — быстрый структурированный ответ
   - **DaData через AI (MCP)** — развёрнутый анализ от нейросети (10–30 сек)
4. Введите ИНН/ОГРН (один или несколько)
5. Получите короткую карточку и используйте кнопки:
   - «📄 Подробнее» — расширенная карточка
   - «📤 Экспорт» — блок реквизитов для копирования
   - «🧩 В CRM» — формат key=value для вставки в CRM

### Пример ввода

```
7721581040
4025456794
```

## Карточка компании (прямой режим, поиск по ИНН/ОГРН)

Бот выводит:

- Наименование (полное и краткое)
- Тип (юр. лицо / ИП) и статус (действующая, ликвидирована и т.д.)
- Дата регистрации / ликвидации
- Реквизиты: ИНН, КПП, ОГРН, ОКПО, ОКТМО, ОКАТО
- Юридический адрес
- Руководитель (должность, ФИО)
- Уставный капитал
- Основной ОКВЭД
- Телефоны и email
- Информация о филиалах

## Технические детали

| Компонент | Технология |
|-----------|-----------|
| Фреймворк бота | aiogram 3.x / pyTelegramBotAPI |
| HTTP-клиент | aiohttp |
| Справочник статусов | party-state.csv (hflabs/party-state) |
| OpenAI SDK | openai (Responses API) |
| FSM | aiogram FSM (MemoryStorage) |
| Конфигурация | python-dotenv |

### Обработка ошибок

- Невалидный ИНН → сообщение с описанием ошибки
- DaData не нашла компанию → «Данные не найдены»
- Ошибка API (сеть, авторизация) → понятное сообщение пользователю + лог
- Длинный ответ (>4096 символов) → автоматическое разбиение на части
- Расшифровка кода статуса ЕГРЮЛ/ЕГРИП (если DaData возвращает `state.code`) по официальному справочнику [hflabs/party-state](https://github.com/hflabs/party-state/blob/master/party-state.csv), включая номер кода в ответе.

## Лицензия

MIT
